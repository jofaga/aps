<?php $__env->startSection('content'); ?>
<div class="container">	
	<div class="admin">
		<h1>Productos</h1>		
	</div>
	<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		<div class="card mt-4">
			<div class="card-body">
				<div class="row">
						<div class="col-9">
							<h2><?php echo e($producto['nombre_producto']); ?></h2>
						</div>
						<div class="col col-3">
							<a href="<?php echo e(route('adminproductos.edit', $producto->id)); ?>" class="btn btn-info">Editar</a>
							<form onsubmit="return confirm('¿Estas seguro de eliminiar el registro?')" class="d-inline-block" method="post" action="<?php echo e(route('adminproductos.destroy', $producto->id)); ?>">
								<?php echo csrf_field(); ?>
								<?php echo method_field('delete'); ?>
								<button type="submit" class="btn btn-danger">Borrar</button>
								<a href="<?php echo e(route('admin/fotos/productos', $producto->id)); ?>" class="btn btn-info">Fotos</a>
							</form>
						</div>
				</div>						
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
</div>
	<div class="container">
		<div class="mt-4">
			<div class="row">
				<div class="col-10">
				<?php echo $productos->links(); ?>

				</div>
				<div class="col-md-2 col-6">
					<a href="adminproductos/create" class="btn btn-success btn-block" role="button">Crear</a>
				</div>
			</div>
		</div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>