<?php $__env->startSection('content'); ?>
<div class="container">	
	<div class="admin">
		<h1>Subtipos de productos</h1>	
	</div>
	
	<?php if($errors->all()): ?>
		<div class="alert alert-danger">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<?php endif; ?>


	<?php $__currentLoopData = $subtipos_productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		<div class="card mt-4">
			<div class="card-body">
				<div class="row">
						<div class="col-10">
							<h2><?php echo e($tipo['subtipo']); ?></h2>
						</div>
						<div class="col col-2">
							
							<form onsubmit="return confirm('¿Estas seguro de eliminiar el registro?')" class="d-inline-block" method="post" action="<?php echo e(route('adminsubtipoproductos.destroy', $tipo->id)); ?>">
								<?php echo csrf_field(); ?>
								<?php echo method_field('delete'); ?>
								<button type="submit" class="btn btn-danger">Borrar</button>
							</form>
						</div>
				</div>						
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
</div>
	<div class="container">
		<div class="mt-4">
			<div class="row">
				<div class="col-10">
				<?php echo $subtipos_productos->links(); ?>

				</div>
				<div class="col-2">
					<a href="adminsubtipoproductos/create" class="btn btn-success btn-block" role="button">Crear</a>
				</div>
			</div>
		</div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>