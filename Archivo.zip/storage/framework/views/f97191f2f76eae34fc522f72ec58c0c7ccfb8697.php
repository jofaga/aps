<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="admin">
		<h1>Crear Servicio</h1>	
	</div>
	<?php if($errors->all()): ?>
		<div class="alert alert-danger">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<?php endif; ?>


	<?php echo Form::open(['url'=>'adminservicios', 'method'=>'POST', 'files'=>true]); ?>

	 <?php echo csrf_field(); ?>
		<div class="form-group">
			<?php echo Form::label('nombre_servicio', 'Nombre del servicio:'); ?>

			<?php echo Form::text('nombre_servicio', null, ['class'=> 'form-control', 'placeholder'=>'Introduce el título del servicio']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('descripcion_servicio', 'Descripción del servicio:'); ?>

			<div class="trumbowyg-background">
				<?php echo Form::textarea('descripcion_servicio', null, ['class'=> 'form-control textarea-content', 'placeholder'=>'Introduce la descripción del servicio']); ?>

			</div>
		</div>

		<div class="col-4">
					
						<div class="form-group">
							<?php echo Form::label('foto', 'Fotografía:'); ?>

							<?php echo Form::file('foto', ['required', 'id'=>'file', 'size'=>'5120']); ?>

							<p id="data"></p>
						</div>
		</div>
		
		<div class="form-group">
			<?php echo Form::submit('Agregar', ['class' => 'btn btn-primary form-control', 'onclick'=>'prueba()', 'id'=>'valida']); ?>

		</div>

	<?php echo Form::close(); ?>

</div>

<?php echo $__env->make('admin.filevalidator', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
<script>
	$('.textarea-content').trumbowyg();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>