<?php $__env->startSection('title'); ?>
	APS Servicios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-banner'); ?>
	Servicios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('seo'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="customers">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="row">
					<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-3 aps-logos-customers">
						<img src="<?php echo e('images/servicios/'.$service->foto); ?>" alt="<?php echo e($service->nombre); ?>" class="img-thumbnail img-fluid">
					</div>
					
					<div class="col-md-3 servicios aps-txt-servicios">
						<h2><?php echo $service->nombre_servicio; ?></h2>
						<?php echo $service->descripcion_servicio; ?>	
					</div>			
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="row justify-content-center">
			<?php echo $services->links(); ?>

		</div>
		<br>	
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>