<?php $__env->startSection('title'); ?>
	APS Servicios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-banner'); ?>
	Proyectos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('seo'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="projects">
	<div class="container">
		<div class="row">
			<div class="card-deck">
				<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($foto->id_proyecto==$project->id && $foto->thumb==true ): ?>
								<?php $ruta = $foto->path_foto; ?>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($project->id_cliente==$cliente->id): ?>
								<?php $customer = $cliente->nombre_cliente; ?>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
				
	
			  	<div class="card text-white bg-dark mb-3">
			    	<a href="<?php echo e(route('/proyecto', $project->id)); ?>"> <img class="card-img-top" src="<?php echo e('images/proyectos/'.$ruta); ?>" alt="<?php echo e($project->nombre_proyecto); ?>">
					    <div class="card-body">
					      <h5 class="card-title"><?php echo $project->nombre_proyecto; ?></h5></a>
					     <ul class="list-group card-text">
						  <li class="list-group-item">Cliente: <?php echo $customer; ?> </li>
						  <li class="list-group-item">Ubicación: <?php echo $project->ubicacion; ?></li>
						  <li class="list-group-item">Fecha de terminación: <?php echo $project->fecha_terminacion; ?></li>
						  <li class="list-group-item">Capacidad: <?php echo $project->capacidad; ?> LPS </li>
						</ul>
					    </div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
		</div>
			<div class="clearfix"></div>
			<br>
			<div class="row justify-content-center">
				<?php echo $projects->links(); ?>

			</div>
				
					<br>	
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>