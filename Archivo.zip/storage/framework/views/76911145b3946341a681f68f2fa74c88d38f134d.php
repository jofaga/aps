<?php $__env->startSection('title'); ?>
	APS Servicios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-banner'); ?>
	Productos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('seo'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div>
	<div class="container">

<div class="row justify-content-center">
	<div class="col-12 aps-filtro-tipos">
		<h2><?php echo e($current); ?></h2>
	</div>
</div>

		<div class="row justify-content-center">						
			<div class="col-12 aps-boton-tipo">
				<div class="btn-group pull-xs-right">
				  <button class="btn dropdown-toggle" type="button" id="buttonMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				    Tipo de producto
				  </button>
				  <div class="dropdown-menu" aria-labelledby="buttonMenu1">
				    <a class="dropdown-item" href="<?php echo e(route('/productos')); ?>">Todos</a>
				    <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				    	<a class="dropdown-item" href="<?php echo e(route('/productos/tipo',$tipo->id)); ?>"><?php echo e($tipo->tipo_producto); ?></a>
				  
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  </div>
				</div>
			</div>



		<div class="row justify-content-center">
			

			<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $__currentLoopData = $producto->fotos_prod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($foto->thumb==true): ?>
					   	<?php $thumb = $foto->path_foto	?>
					 <?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<div class="col-md-4 aps-logos-customers">
					<div class="card-deck">
					  <div class="card text-white bg-dark mb-3">
					   <a href="<?php echo e(route('/producto',$producto->id )); ?> "> 
					   	<img class="card-img-top" src="<?php echo e(asset('images/productos/'.$thumb)); ?>" alt="<?php echo e($producto->nombre_producto); ?>">
					    <div class="card-body">
					      <h5 class="card-title"><?php echo e($producto->nombre_producto); ?></h5></a>
					    </div>
					  </div>
					</div>




				</div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="clearfix"></div>
		<div class="row justify-content-center">
			<?php echo $productos->links(); ?>

		</div>
		<br>	
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>