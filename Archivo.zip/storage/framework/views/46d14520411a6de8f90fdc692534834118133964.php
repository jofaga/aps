<?php $__env->startSection('content'); ?>
<div class="container">	
	<div class="admin">
		<h1>Edificios</h1>		
	</div>
	<?php $__currentLoopData = $edificios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $edificio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		<div class="card mt-4">
			<div class="card-body">
				<div class="row">
						<div class="col-8">
							<h2><?php echo e($edificio['nombre']); ?></h2>
						</div>
						<div class="col col-4">
							<a href="<?php echo e(route('adminedificios.edit', $edificio->id)); ?>" class="btn btn-info">Editar</a>
							<form onsubmit="return confirm('¿Estas seguro de eliminiar el registro?')" class="d-inline-block" method="post" action="<?php echo e(route('adminedificios.destroy', $edificio->id)); ?>">
								<?php echo csrf_field(); ?>
								<?php echo method_field('delete'); ?>
								<button type="submit" class="btn btn-danger">Borrar</button>
								<a href="<?php echo e(route('admintelefonosedificios.show', $edificio->id)); ?>" class="btn btn-info">Teléfonos</a>
							</form>
								<?php if($edificio->contacto): ?>
									<button class="btn btn-warning"><i class="far fa-check-square" data-toggle="tooltip" data-html="true" title="Datos para contacto"></i></button>
								<?php else: ?>
									<a  href="<?php echo e(route('admin/edificio/contacto', array($edificio->id))); ?>" class="btn btn-primary"><i class="far fa-check-square"></i></a>
								<?php endif; ?>	
						</div>
				</div>						
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
</div>
<br>
<div class="container">
	<div class="row">
		<div class="col-md-8 col-12">
			<div class="card">
				<div class="card-header">
					<h4>Simbología</h4>
				</div>
				<div class="card-body">
					 <p>Indica que los datos del edificio aparecerán en la sección de contacto : <span class="far fa-check-square btn-warning"></span></p> 
						 <p>Indica que los datos del edificio NO aparecerán en la sección de contacto : <span class="far fa-check-square btn-primary"></span></p>  
				</div>
			</div>
		</div>
	</div>
</div>


	<div class="container">
		<div class="mt-4">
			<div class="row">
				<div class="col-10">
					
					
				<?php echo $edificios->links(); ?>

				</div>
				<div class="col-md-2 col-6">
					<a href="adminedificios/create" class="btn btn-success btn-block" role="button">Crear</a>
				</div>

			</div>
		</div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>