<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="admin">
		<h1>Crear Edificio</h1>	
	</div>
	<?php if($errors->all()): ?>
		<div class="alert alert-danger">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<?php endif; ?>


	<?php echo Form::open(['url'=>'adminedificios']); ?>

	 <?php echo csrf_field(); ?>
		<div class="form-group">
			<?php echo Form::label('nombre', 'Nombre del Edificio:'); ?>

			<?php echo Form::text('nombre', null, ['class'=> 'form-control', 'placeholder'=>'Introduce el nombre del Edificio', 'required']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('calle', 'Calle del Edificio:'); ?>

			<?php echo Form::text('calle', null, ['class'=> 'form-control', 'placeholder'=>'Introduce la calle', 'required']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('colonia', 'Colonia del Edificio:'); ?>

			<?php echo Form::text('colonia', null, ['class'=> 'form-control', 'placeholder'=>'Introduce la colonia', 'required']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('cp', 'Código Postal:'); ?>

			<?php echo Form::text('cp', null, ['class'=> 'form-control', 'placeholder'=>'Introduce el Código Postal', 'required']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('ciudad', 'Introduce la ciudad:'); ?>

			<?php echo Form::text('ciudad', null, ['class'=> 'form-control', 'placeholder'=>'Introduce la ciudad', 'required']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('estado', 'Estado:'); ?>

			<?php echo Form::select('estado',$estado, null, ['class'=>'form-control', 'placeholder'=>'Selecciona el estado']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('pais', 'Pais:'); ?>

			<?php echo Form::select('pais',$pais, null, ['class'=>'form-control', 'placeholder'=>'Selecciona el pais']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('horario', 'Horario:'); ?>

			<?php echo Form::text('horario', null, ['class'=> 'form-control', 'placeholder'=>'Introduce el Horario', 'required']); ?>

		</div>
		
		<div class="form-group">
			<?php echo Form::submit('Agregar', ['class' => 'btn btn-primary form-control']); ?>

		</div>

	<?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	$('.chosen-select').chosen({
		placeholder_text_multiple: 'Seleccionar'
	});
	$('.textarea-content').trumbowyg();
	$('.datepicker').datepicker({
		format: "yyyy-mm-dd",
		language: "es",
		autoclose: true
	});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>