<?php $__env->startSection('title'); ?>
	APS Servicios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-banner'); ?>
	Proyectos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('seo'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="proyecto">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
	  				<div class="carousel-inner">
	  					<?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  						<div class="carousel-item <?php if($foto->thumb==true){ echo('active');} ?>">
	      					<img class="d-block w-100 aps-carrousel-proy" src="../images/proyectos/<?php echo $foto->path_foto; ?>" alt="<?php echo e($proyecto->nombre_proyecto); ?>">
	    					</div>
	    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
	  			</div>
				  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
				    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
				    <span class="sr-only">Previous</span>
				  </a>
				  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
				    <span class="carousel-control-next-icon" aria-hidden="true"></span>
				    <span class="sr-only">Next</span>
				  </a>
				</div>
			</div>
			</div>
			<br>
			<div class="row">
			<div class="col-md-12">
				<h1><?php echo e($proyecto->nombre_proyecto); ?></h1>
				<hr>
				<h4>Ubicación del proyecto:</h4>
				<?php echo $proyecto->ubicacion; ?>

				<hr>
				<h4>Fecha de terminación:</h4>
				<?php echo $proyecto->fecha_terminacion; ?>

				<hr>
				<h4>Cliente:</h4>
				<img class="img-thumbnail img-fluid aps-proy-cliente"  src="../images/logos_clientes/<?php echo $cliente->logo; ?>" alt="<?php echo e($cliente->nombre_cliente); ?>">
				<br>
				<?php echo $cliente->nombre_cliente; ?>

				<hr>
				<h4>Capacidad en lps:</h4>
				<?php echo $proyecto->capacidad; ?>

				<hr>
				<h4>Descripción del proyecto:</h4>
				<?php echo $proyecto->descripcion; ?>			
			</div>
				<div class="clearfix"></div>
		</div>
	</div>

<div class="container">
	<div class="row">
		<div class="col-md-12">
			<h2>Otros proyectos</h2>
		</div>
			
				<?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php $__currentLoopData = $fotosproy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotoproy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($fotoproy->id_proyecto==$project->id && $fotoproy->thumb==true ): ?>
								<?php $ruta = $fotoproy->path_foto; ?>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					<div class="col-md-4">
						<a href="<?php echo e(route('/proyecto', $project->id)); ?>"> <img class="img-thumbnail aps-fade" src="/images/proyectos/<?php echo $ruta; ?>" alt="<?php echo e($project->nombre_proyecto); ?>">
							<div class="aps-fade-middle">
								<div class="aps-fade-text">
									<?php echo e($project->nombre_proyecto); ?>

								</div>
							</div>
						</a>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
		<div class="clearfix"></div>
	<div class=" col-md-12">
					<div class="aps-pagination">
						<?php echo $projects->links(); ?>

					</div>
					

				</div>		
	</div>		

				
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>