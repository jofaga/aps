<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="admin">
		<h1>Administración de equipo de APS</h1>	
	</div>
	<?php if($errors->all()): ?>
		<div class="alert alert-danger">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<?php endif; ?>

		<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
			<div class="card mt-4">
				<div class="card-body">
					<div class="row">
							<div class="col-6">
								<h2><?php echo e($usuario['nombre']); ?></h2>
							</div>
							<div class="col-md 6 col-6">
								<a href="<?php echo e(route('adminusuarios.edit', $usuario->id)); ?>" class="btn btn-info">Editar</a>
								<form onsubmit="return confirm('¿Estas seguro de eliminiar el registro?')" class="d-inline-block" method="post" action="<?php echo e(route('adminusuarios.destroy', $usuario->id)); ?>">
									<?php echo csrf_field(); ?>
									<?php echo method_field('delete'); ?>
									<button type="submit" class="btn btn-danger">Borrar</button>
									<a href="<?php echo e(route('admin/fotos/usuarios', $usuario->id)); ?>" class="btn btn-dark">Fotos</a>
									<a href="<?php echo e(route('admin/correos/usuarios', $usuario->id)); ?>" class="btn btn-warning">Correos</a>
									<a href="<?php echo e(route('admin/telefonos/usuarios', $usuario->id)); ?>" class="btn btn-secondary">Teléfonos</a>
								</form>
							</div>
					</div>						
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
	</div>
</div>
	<div class="container">
		<div class="mt-4">
			<div class="row">
				<div class="col-10">
				<?php echo $usuarios->links(); ?>

				</div>
				<div class="col-md-2 col-6">
					<a href="adminusuarios/create" class="btn btn-success btn-block" role="button">Crear</a>
				</div>
			</div>
		</div>
	</div>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>