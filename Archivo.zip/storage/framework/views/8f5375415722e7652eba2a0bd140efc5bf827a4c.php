<?php $__env->startSection('title'); ?>
	APS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-banner'); ?>
	Clientes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('seo'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="customers">
	<div class="container">
		<div class="row">
			<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-4 aps-logos-customers">
				<img src="<?php echo e('images/logos_clientes/'.$customer->logo); ?>" alt="<?php echo e($customer->nombre_cliente); ?>" class="img-thumbnail img-fluid">
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="clearfix"></div>
		<div class="row justify-content-center">
			<?php echo $customers->links(); ?>

		</div>
		
		<br>	
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>