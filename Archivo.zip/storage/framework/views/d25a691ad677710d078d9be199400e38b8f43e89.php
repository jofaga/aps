<?php $__env->startSection('content'); ?>
<div class="container">	
	<div class="admin">
		<h1>Telefonos de Edificio: <?php echo e($item->nombre); ?></h1>	
	</div>
		<?php if($errors->all()): ?>
			<div class="alert alert-danger">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endif; ?>	
		<?php if(session()->has('message')): ?>
			<div class="alert alert-success">
				<?php echo e(session()->get('message')); ?>

			</div>
		
		<?php endif; ?>
		<div class="row">
			<?php $__currentLoopData = $telefonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telefono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>					
				<div class="col-md-3">
					<div class="card">	
					<div class="card-header">
							Telefonos <?php echo e($item->nombre); ?>			
					</div>				
						<div class="card-body">
								<h3><?php echo e($telefono->telefono); ?> </h3>
								<form onsubmit="return confirm('¿Estas seguro de eliminiar el teléfono?')" class="d-inline-block" method="post" action="<?php echo e(route('admintelefonosedificios.destroy', $telefono->id)); ?>">
									<br>
									<?php echo csrf_field(); ?>
									<?php echo method_field('delete'); ?>
									<button type="submit" class="btn btn-danger">Borrar teléfono</button>
								</form>						
						</div>
					</div>
				</div>	
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>					
		</div>							
</div>
	<div class="container">
		<div class="mt-4">
			<div class="row">
				
				<div class="col-4">
					<?php echo Form::open(['url'=>'admintelefonosedificios', 'method'=>'POST', 'name'=>'miformulario' ]); ?>

					 <?php echo csrf_field(); ?>
						<div class="card">
							<div class="card-header">
								<strong>Dar de alta nuevo teléfono</strong> 
							</div>

							<div class="card-body">
								<div class="form-group">
									<?php echo Form::label('telefono', 'Teléfono:'); ?>

									<?php echo Form::tel('telefono',null ,['required','id'=>'idcodigo', 'placeholder'=>'Ingresa Telefono']); ?>

								</div>
									<input type="hidden" id="id_edificio" name="id_edificio" value="<?php echo $item->id; ?>">
								<div class="form-group">
									<?php echo Form::submit('Agregar', ['class' => 'btn btn-primary form-control']); ?>

								</div>
							</div>
						</div>
					<?php echo Form::close(); ?>


				</div>
			</div>
		</div>
	</div>

<?php echo $__env->make('admin.validanumeros', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

	


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>