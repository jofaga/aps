<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="admin">
		<h1>Editar tipo de proyecto: <?php echo e($tipo->tipo_proyecto); ?></h1>	
	</div>
	
	<?php if($errors->all()): ?>
		<div class="alert alert-danger">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<?php endif; ?>

	<?php if(session()->has('message')): ?>
		<div class="alert alert-success">
			<?php echo e(session()->get('message')); ?>

		</div>
	<?php endif; ?>

	<?php echo Form::model($tipo, ['method' => 'PATCH', 'action' => ['Tipo_proyectosController@update', $tipo->id]]); ?>

	<?php echo csrf_field(); ?>
		<div class="form-group">
			<?php echo Form::label('_proyecto', 'Tipo: '); ?>

			<?php echo Form::text('tipo_proyecto', null, ['class'=>'form-control', 'required']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('tag', 'Tag: '); ?>

			<?php echo Form::text('tag', null, ['class'=>'form-control', 'required']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::submit('Editar', ['class' => 'btn btn-primary form-control']); ?>

		</div>
	<?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>