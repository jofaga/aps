<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="admin">
		<h1>Crear Proyecto</h1>	
	</div>
	<?php if($errors->all()): ?>
		<div class="alert alert-danger">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<?php endif; ?>


	<?php echo Form::open(['url'=>'adminproyectos', 'name'=>'proyectos']); ?>

	 <?php echo csrf_field(); ?>
		<div class="form-group">
			<?php echo Form::label('nombre_proyecto', 'Nombre del proyecto:'); ?>

			<?php echo Form::text('nombre_proyecto', null, ['required','class'=> 'form-control', 'placeholder'=>'Introduce el nombre del proyecto']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('descripcion', 'Descripción del proyecto:'); ?>

			<div class="trumbowyg-background">
				<?php echo Form::textarea('descripcion', null, ['required','class'=> 'form-control textarea-content', 'placeholder'=>'Introduce la descripción del proyecto']); ?>

			</div>
		</div>
		<div class="form-group">
			<?php echo Form::label('fecha_terminacion', 'Fecha de terminación:'); ?>

			<?php echo Form::text('fecha_terminacion', null, ['required','class'=> 'form-control datepicker', 'placeholder'=>'Selecciona la fecha de terminación']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('ubicacion', 'Ubicación del proyecto:'); ?>

			<?php echo Form::text('ubicacion', null, ['required','class'=> 'form-control', 'placeholder'=>'Introduce la ubicación del proyecto']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('tipo', 'Tipo de proyecto:'); ?>

			<?php echo Form::select('tipo[]',$tipo, null, ['required','class'=>'form-control chosen-select', 'multiple']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('cliente', 'Cliente:'); ?>

			<?php echo Form::select('id_cliente',$cliente, null, ['required','class'=>'form-control', 'placeholder'=>'Selecciona el cliente']); ?>

		</div>
		<div class="form-group">
			<?php echo Form::label('capacidad', 'Capacidad del proyecto (Litros):'); ?>

			<?php echo Form::text('capacidad', null, ['required','id'=>'idcodigo','class'=> 'form-control', 'placeholder'=>'Introduce la capacidad del proyecto' ]); ?>

		</div>
		<div class="form-group">
			<?php echo Form::submit('Agregar', ['class' => 'btn btn-primary form-control']); ?>

		</div>

	<?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
	$('.chosen-select').chosen({
		placeholder_text_multiple: 'Selecciona los tipos de proyectos'
	});
	$('.textarea-content').trumbowyg();
	$('.datepicker').datepicker({
		format: "yyyy-mm-dd",
		language: "es",
		autoclose: true
	});

window.addEventListener("load", function() {
proyectos.capacidad.addEventListener("keypress", soloNumeros, false);
});

//Solo permite introducir numeros.
function soloNumeros(e){
  var key = window.event ? e.which : e.keyCode;
  if (key < 48 || key > 57) {
    e.preventDefault();
  }
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>