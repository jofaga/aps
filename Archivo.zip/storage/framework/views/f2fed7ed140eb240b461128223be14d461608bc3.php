<?php $__env->startSection('content'); ?>
<div class="container">	
	<div class="admin">
		<h1>Correos de: <?php echo e($usuario->nombre); ?></h1>	
	</div>
		<?php if($errors->all()): ?>
			<div class="alert alert-danger">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endif; ?>	
		<?php if(session()->has('message')): ?>
			<div class="alert alert-success">
				<?php echo e(session()->get('message')); ?>

			</div>
		
		<?php endif; ?>
		<div class="row">
			<?php $__currentLoopData = $correos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $correo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>					
				<div class="col-md-4">
					
					<div class="card">
  						<div class="card-header">
    						Correo APS
  						</div>
  							 <div class="card-body">
					
								<p><?php echo $correo->correo; ?></p>
								<form onsubmit="return confirm('¿Estas seguro de eliminiar el correo?')" class="d-inline-block" method="post" action="<?php echo e(route('admincorreos.destroy', $correo->id)); ?>">
									<br>
									<?php echo csrf_field(); ?>
									<?php echo method_field('delete'); ?>
									<button type="submit" class="btn btn-danger">Borrar Correo</button>
								</form>		
						</div>
					</div>
				</div>	
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>					
		</div>							
</div>
	<div class="container">
		<div class="mt-4">
			<div class="row">
				<div class="col-6">
					<?php echo Form::open(['url'=>'admincorreos', 'method'=>'POST']); ?>

					 <?php echo csrf_field(); ?>
						<div class="form-group">
							<?php echo Form::label('correo', 'Correo:'); ?>

							<?php echo Form::text('correo',null ,['class'=>'form-control','required', 'placeholder'=>'Introduce el correo']); ?>

							<p id="data"></p>
						</div>
							<input type="hidden" id="id_entus" name="id_entus" value="<?php echo $usuario->id; ?>">
						<div class="form-group">
							<?php echo Form::submit('Agregar', ['class' => 'btn btn-primary form-control']); ?>

						</div>
					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>


<?php $__env->stopSection(); ?>

	


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>