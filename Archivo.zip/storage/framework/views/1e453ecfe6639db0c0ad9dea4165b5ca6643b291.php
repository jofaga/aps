<?php $__env->startSection('title'); ?>
	APS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-banner'); ?>
	Equipo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('seo'); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<div class="customers">
	<div class="container">
		<div class="row justify-content-center">
			<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($foto->id_usuario==$member->id && $foto->thumb==true ): ?>
						<?php $ruta = $foto->path_foto; ?>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-4 aps-logos-customers">
				<a href="#" data-toggle="modal" data-target="#<?php echo $member->nombre; ?>" >
					<img src="<?php echo e('images/crew/'.$ruta); ?>" alt="<?php echo e($member->nombre); ?>" class="img-thumbnail img-fluid">
				</a>
			</div>
				
			<div class="aps-modal-crew-txt">
				<div class="modal fade" id="<?php echo $member->nombre; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  					<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title" id="exampleModalLongTitle">Miembro: <?php echo $member->nombre; ?></h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body">
					        <div class="row">
					        	<div class="col-12 col-sm-12 col-md-6">
					        		<img src="<?php echo e(asset('images/crew/'.$ruta)); ?>" class="img-responsive mx-auto d-block aps-img-crew"   alt="Aqua Productos y Servicios">		
					        	</div>
					        	
					        
					        	<div class="col-12 col-sm-12 col-md-6">
					        		<div class="aps-data">
					        		<h5 class="oi oi-phone"> Teléfonos:</h5>
					        		
					        		<?php $__currentLoopData = $telefonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $telefono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        			<?php if($member->id==$telefono->id_entus): ?>
					        				<?php echo $telefono->telefono; ?>|
					        			<?php endif; ?>
					        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					        		<br>
					        		</div>
					        		<div class="aps-data">
					        		<h5 class="oi oi-envelope-closed"> Correos:</h5>
					        		<?php $__currentLoopData = $correos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $correo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					        			<?php if($member->id==$correo->id_entus): ?>
					        				<a href="mailto:<?php echo $correo->correo; ?>?subject=contacto" "Sitio APS"><?php echo $correo->correo; ?></a>
					        			<?php endif; ?>
					        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					        		<br>
					        		</div>
					        		<div class="aps-data">
					        	<h4 class="oi oi-person"> Cargo:</h4><?php echo $member->cargo; ?>

					        	</div>
					        	</div>
					      
					        	<div class="col-12">
					        		<div class="aps-abstract">
					        			<?php echo $member->descripcion; ?>

					        		</div>
					        	</div>
					        </div>
					        
					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
					      </div>
					    </div>
					  </div>
					</div>
				</div>






			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<div class="clearfix"></div>
		<div class="row justify-content-center">
			<?php echo $members->links(); ?>

		</div>
		
		<br>	
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>