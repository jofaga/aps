<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="admin">
		<h1>Crear Producto</h1>	
	</div>
	
	<?php if($errors->all()): ?>
		<div class="alert alert-danger">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<?php endif; ?>


	<?php echo Form::open(['url'=>'adminproductos']); ?>

	 <?php echo csrf_field(); ?>
		<div class="form-group">
			<?php echo Form::label('nombre_producto', 'Nombre del producto:'); ?>

			<?php echo Form::text('nombre_producto', null, ['class'=> 'form-control', 'required']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('descripcion_producto', 'Descripción del producto:'); ?>

			<div class="trumbowyg-background">
				<?php echo Form::textarea('descripcion_producto', null, ['class'=> 'form-control textarea-content', 'required']); ?>	
			</div>
		</div>

		<div class="form-group">
			<?php echo Form::label('id_tipo', 'Tipo de productos:'); ?>

			<?php echo Form::select('id_tipo',$tipos, null, ['class'=>'form-control chosen-select']); ?>

		</div>
		
		<div class="form-group">
			<?php echo Form::submit('Agregar', ['class' => 'btn btn-primary form-control', 'onclick'=>'prueba()', 'id'=>'valida']); ?>

		</div>
	<?php echo Form::close(); ?>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	$('.textarea-content').trumbowyg();
	$('.chosen-select').chosen({
		placeholder_text: 'Selecciona una opción'
	});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>