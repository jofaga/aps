<?php $__env->startSection('title'); ?>
	APS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-banner'); ?>
	Empresa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('seo'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="about">
<div class="container">
	
		<div class="row justify-content-around">
			
				<?php $__currentLoopData = $caracteristicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caracteristica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-4">
					<div class="esfera caracteristicas">
						<img src="<?php echo e(asset('images/site/esfera_3.png')); ?>" class="img-responsive"   alt="">
						<div class="links-about">
							<a href="#" data-toggle="modal" data-target="#<?php echo $caracteristica->nombre; ?>"><?php echo $caracteristica->nombre; ?></a>	
						</div>	
					</div>
				</div>

				<div class="modal fade" id="<?php echo $caracteristica->nombre; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  					<div class="modal-dialog modal-dialog-centered" role="document">
					    <div class="modal-content">
					      <div class="modal-header">
					        <h5 class="modal-title aps-modal-about" id="exampleModalLongTitle"><?php echo $caracteristica->nombre; ?></h5>
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
					      </div>
					      <div class="modal-body aps-modal-about">
					        <?php echo $caracteristica->contenido; ?>

					        <div class="row">
					        	<div class="col-12">
					        		<img src="<?php echo e(asset('images/site/logo_2.png')); ?>" class="img-responsive mx-auto d-block"   alt="Aqua Productos y Servicios">		
					        	</div>
					        </div>
					        
					      </div>
					      <div class="modal-footer">
					        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerar</button>
					      </div>
					    </div>
					  </div>
					</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
		</div>
		<div class="row justify-content-center">
		<?php echo $caracteristicas->links(); ?>

		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
	$('#myModal').on('shown.bs.modal', function () {
  $('#myInput').trigger('focus')
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>