<?php $__env->startSection('content'); ?>
<div class="container">	
	<div class="admin">
		<h1>Fotografías de Producto <?php echo e($producto->nombre_producto); ?></h1>	
	</div>
		<?php if($errors->all()): ?>
			<div class="alert alert-danger">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endif; ?>	
		<?php if(session()->has('message')): ?>
			<div class="alert alert-success">
				<?php echo e(session()->get('message')); ?>

			</div>
		
		<?php endif; ?>
		<div class="row">
			<?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>					
				<div class="col-md-4">
					<div class="panel panel-default">					
						<div class="panel-body">
								<img height="200px" width="300px"  src="/images/productos/<?php echo $foto->path_foto; ?>" class="img-responsive">
								<form onsubmit="return confirm('¿Estas seguro de eliminiar la fotografía?')" class="d-inline-block" method="post" action="<?php echo e(route('adminfotos.destroy', $foto->id)); ?>">
									<br>
									<?php echo csrf_field(); ?>
									<?php echo method_field('delete'); ?>
									<button type="submit" class="btn btn-danger">Borrar Imagen</button>
								</form>	
								<?php if($foto->thumb): ?>
									<button class="btn btn-warning"><i class="fas fa-heart" data-toggle="tooltip" data-html="true" title="Imagen para galería en productos"></i></button>
								<?php else: ?>
									<a  href="<?php echo e(route('admin/fotos/productos/thumb', array($producto->id, $foto->id))); ?>" class="btn btn-primary"><i class="fas fa-heart"></i></a>
								<?php endif; ?>								
						</div>
					</div>
				</div>	
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>					
		</div>							
</div>
	<div class="container">
		<div class="mt-4">
			<div class="row">
				
				<div class="col-4">
					<?php echo Form::open(['url'=>'adminfotosproductos', 'method'=>'POST', 'files'=>true]); ?>

					 <?php echo csrf_field(); ?>
						<div class="form-group">
							<?php echo Form::label('path_foto', 'Fotografía:'); ?>

							<?php echo Form::file('path_foto', ['required', 'id'=>'file', 'size'=>'5120']); ?>

							<p id="data"></p>
						</div>
							<input type="hidden" id="id_producto" name="id_producto" value="<?php echo $producto->id; ?>">
						<div class="form-group">
							<?php echo Form::submit('Agregar', ['class' => 'btn btn-primary form-control', 'onclick'=>'prueba()', 'id'=>'valida']); ?>

						</div>
					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>

<?php echo $__env->make('admin.filevalidator', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

	


<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>