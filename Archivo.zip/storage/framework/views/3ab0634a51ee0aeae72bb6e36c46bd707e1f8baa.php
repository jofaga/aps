<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="admin">
		<h1>Crear característica de APS</h1>	
	</div>
	<?php if($errors->all()): ?>
		<div class="alert alert-danger">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<?php endif; ?>
	
	<?php echo Form::open(['url'=>'admincaracteristicas', 'method'=>'POST']); ?>

	 <?php echo csrf_field(); ?>

		<div class="form-group">
			<?php echo Form::label('nombre', 'Nombre de la característica:'); ?>

			<?php echo Form::text('nombre',null ,['required','class'=>'form-control']); ?>

		</div>

		<div class="form-group">
			<?php echo Form::label('contenido', 'Contenido de la característica:'); ?>

			<div class="trumbowyg-background">
				<?php echo Form::textarea('contenido', null, ['class'=> 'form-control textarea-content', 'placeholder'=>'Introduce la descripción']); ?>

			</div>
		</div>
		

		<div class="form-group">
			<?php echo Form::submit('Agregar', ['class' => 'btn btn-primary form-control']); ?>

		</div>

	<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
	$('.textarea-content').trumbowyg();

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>