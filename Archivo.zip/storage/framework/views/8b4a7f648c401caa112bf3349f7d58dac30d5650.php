<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="admin">
		<h1>Editar cliente: <?php echo e($cliente->nombre_cliente); ?></h1>	
	</div>
	
	<?php if($errors->all()): ?>
		<div class="alert alert-danger">
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<?php endif; ?>

	<?php if(session()->has('message')): ?>
		<div class="alert alert-success">
			<?php echo e(session()->get('message')); ?>

		</div>
	<?php endif; ?>

	<?php echo Form::model($cliente, ['method' => 'PATCH', 'files'=>true, 'action' => ['ClientesController@update', $cliente->id]]); ?>

	<?php echo csrf_field(); ?>
				
		<div class="form-group">
			<?php echo Form::label('logo', 'Logo:'); ?>

			<p id="data"></p>
			<?php echo Form::file('logo', ['required', 'id'=>'file', 'size'=>'5120']); ?>

		</div>

		<div class="admin form-group">
			<h1>Logo del cliente</h1>	
			<img height="300px" width="300px" src="/images/logos_clientes/<?php echo e($cliente->logo); ?>" class="img-responsive">	
		</div>		

		<div class="form-group">
			<?php echo Form::submit('Editar', ['class' => 'btn btn-primary form-control', 'onclick'=>'prueba()', 'id'=>'valida']); ?>

		</div>
	<?php echo Form::close(); ?>

		
		

</div>
<?php echo $__env->make('admin.filevalidator', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>