<?php $__env->startSection('title'); ?>
	APS Servicios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-banner'); ?>
	Laboratorio
<?php $__env->stopSection(); ?>

<?php $__env->startSection('seo'); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $sel=$fotos[mt_rand(0, count($fotos)-1)];?>




<div class="container">
	<div class="row">
		<div class="col-12">
			<div class="aps-lab-carrousel">
				<div id="aps-carrousel" class="carousel slide" data-ride="carousel">
		  			<div class="carousel-inner">
						<?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="carousel-item <?php if($foto->id==$sel->id){ echo('active');} ?>">
								<img class="d-block w-100 aps-carrousel-proy" src="../images/laboratorio/<?php echo $foto->path_foto; ?>" alt="Laboratorio APS">
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  
		  			</div>
					  <a class="carousel-control-prev" href="#aps-carrousel" role="button" data-slide="prev">
					    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
					    <span class="sr-only">Previous</span>
					  </a>
					  <a class="carousel-control-next" href="#aps-carrousel" role="button" data-slide="next">
					    <span class="carousel-control-next-icon" aria-hidden="true"></span>
					    <span class="sr-only">Next</span>
					  </a>
				</div>
			</div>
		</div>
		</div>
		<div class="row">
			<div class="col-md-6 col-12 aps-txt-lab">
					<?php echo $info->textolaboratorio; ?>

			</div>
			<div class="col-md-6 col-12 aps-txt-lab">
				<?php $__currentLoopData = $servicioslab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serviciolab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<h3><?php echo $serviciolab->nombre_servicio_lab; ?></h3>
					<?php echo $serviciolab->descripcion_servicio_lab; ?>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>