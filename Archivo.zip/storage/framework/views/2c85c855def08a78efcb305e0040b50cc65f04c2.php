<?php $__env->startSection('content'); ?>
<div class="container">	
	<div class="admin">
		<h1>Servicios</h1>		
	</div>
	<?php if($errors->all()): ?>
			<div class="alert alert-danger">
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		<?php endif; ?>	
		<?php if(session()->has('message')): ?>
			<div class="alert alert-success">
				<?php echo e(session()->get('message')); ?>

			</div>
		
		<?php endif; ?>
	<?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
		<div class="card mt-4">
			<div class="card-body">
				<div class="row">
						<div class="col-md-10 col-8">
							<h2><?php echo e($servicio['nombre_servicio']); ?></h2>
						</div>
						<div class="col-md-2 col-4">
							<a href="<?php echo e(route('adminservicios.edit', $servicio->id)); ?>" class="btn btn-info">Editar</a>
							<form onsubmit="return confirm('¿Estas seguro de eliminiar el registro?')" class="d-inline-block" method="post" action="<?php echo e(route('adminservicios.destroy', $servicio->id)); ?>">
								<?php echo csrf_field(); ?>
								<?php echo method_field('delete'); ?>
								<button type="submit" class="btn btn-danger">Borrar</button>
							</form>
						</div>
				</div>						
			</div>
		</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
</div>
	<div class="container">
		<div class="mt-4">
			<div class="row">
				<div class="col-10">
				<?php echo $servicios->links(); ?>

				</div>
				<div class="col-md-2 col-6">
					<a href="adminservicios/create" class="btn btn-success btn-block" role="button">Crear</a>
				</div>
			</div>
		</div>
	</div>	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>