<?php $__env->startSection('title'); ?>
	APS Servicios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-banner'); ?>
	Producto: <?php echo e($producto->nombre_producto); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('seo'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="proyecto">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
	  				<div class="carousel-inner">
	  					<?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	  						<div class="carousel-item <?php if($foto->thumb==true){ echo('active');} ?>">
	      					<img class="d-block w-100 aps-carrousel-proy" src="../images/productos/<?php echo $foto->path_foto; ?>" alt="<?php echo e($producto->nombre_producto); ?>">
	    					</div>
	    				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	  
	  				</div>
				  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
				    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
				    <span class="sr-only">Previous</span>
				  </a>
				  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
				    <span class="carousel-control-next-icon" aria-hidden="true"></span>
				    <span class="sr-only">Next</span>
				  </a>
				</div>
			</div>
			</div>
			<br>
			<div class="row">
			<div class="col-md-12">
				<h1><?php echo e($producto->nombre_producto); ?></h1>
				<hr>
				<h4>Descripción:</h4>
				<?php echo $producto->descripcion_producto; ?>

			</div>
				<div class="clearfix"></div>
		</div>
	</div>				
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>